/* eslint-disable @typescript-eslint/no-unused-vars */
import React from 'react';
import { cComponenteCustos } from 'src/types/ComponenteCustos';

export const componenteCustosNova: cComponenteCustos = {
  id: 0,
  descricao: '-',
  ativo: false,
};
