/* eslint-disable @typescript-eslint/no-unused-vars */
import React from 'react';
import { cCompetencia } from 'src/types/Competencia';

export const competenciaNova: cCompetencia = {
  id: 49,
  mes: 1,
  mesAno: '1/2022',
};
