import styled from 'styled-components';

export const ContainerAlt = styled.div`
  width: 100%;
  margin: 0px 0px;
  text-align: right;
  padding: 10px;
`;
