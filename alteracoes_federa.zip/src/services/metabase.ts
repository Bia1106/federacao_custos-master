export const MetabaseURL = 'http://45.35.104.231:3000/public/dashboard';

export const PainelPrincipal = `${MetabaseURL}/886a5170-9703-4bd6-b23d-6b1128eef81f`;

// 45.35.104.231:3000/public/dashboard/45b46808-b70f-4182-bdb9-8da8f8cdc3f0

export const PainelRelarioDespesa = `${MetabaseURL}/45b46808-b70f-4182-bdb9-8da8f8cdc3f0`;

// 45.35.104.231:3000/public/dashboard/9c2f707e-62c7-4b8a-a486-278616ca1f50

export const PainelRelarioReceita = `${MetabaseURL}/9c2f707e-62c7-4b8a-a486-278616ca1f50`;

// Resultado Médio Mensal
export const ResultadoMedioMensao = `${MetabaseURL}/c125c972-a1f7-47f0-9132-5874aa70344f`;

// http://45.35.104.231:3000/public/dashboard/d60bf555-e3bd-4432-9549-aa0b77c25bc5?hospital=27014&#hide_parameters=phospital,pusuario,ano,pcentrocusto,ptiporecurso
export const DinamicaDespesa = `${MetabaseURL}/d60bf555-e3bd-4432-9549-aa0b77c25bc5`;

// http://45.35.104.231:3000/public/dashboard/692cab4e-d6f3-4113-b932-3568f4208030
export const DinamicaReceita = `${MetabaseURL}/692cab4e-d6f3-4113-b932-3568f4208030`;
