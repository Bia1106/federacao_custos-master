export type cBancos = {
  id?: number;
  codBanco?: string;
  nmBanco?: string;
};
