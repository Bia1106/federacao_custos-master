export type cTipoRecurso = {
  id: number;
  dsTipoRecurso: string;
};
