export type cPopUP = {
  Mensagem?: string;
  show?: boolean;
};
