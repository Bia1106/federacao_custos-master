export type cCriterio = {
  id?: number;
  dsCriterio?: string;
  ativo: boolean;
};
