// define your option type
export type MyOption = { label: string; value: number };
