import { cCriterio } from './Criterio';

export type cComponenteCustos = {
  ativo: boolean;
  descricao: string;
  id: number;
};
