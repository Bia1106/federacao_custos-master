export type cMensagem = {
  Mensagem?: string;
  TipoMensagem?: string;
};
