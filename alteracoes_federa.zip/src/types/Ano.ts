export type cAno = {
  idAno: number;
  ano: number;
};
