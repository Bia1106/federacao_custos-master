export type cRoles = {
  id: number;
  name: string;
  authority: string;
};
