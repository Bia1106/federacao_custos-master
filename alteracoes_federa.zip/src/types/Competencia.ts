export type cCompetencia = {
  id: number;
  mes?: number;
  mesAno?: string;
};
