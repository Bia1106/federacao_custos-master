module.exports = {
    singleQuote: true, // Força utilização de aspas simples
    trailingComma: 'all', // Força utilização da virgula no fim de objetos
    arrowParens: 'avoid', // Força não utilização de parênteses com funções de um único parâmetro.
}